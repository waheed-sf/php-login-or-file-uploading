<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller
{
	public function Index()
	{
		$this->load->view('Home/Header.php');
		$this->load->view('Home/index.php');
		$this->load->view('Home/Footer.php');
	}
	public function Contact()
	{
		$this->load->view('Home/Header.php');
		$this->load->view('Home/Contactus.php');
		$this->load->view('Home/Footer.php');
	}
	public function About()
	{
		$this->load->model('myModel');
		data['name'] = myModel->getNames();

		$this->load->view('Home/Header.php');
		$this->load->view('Home/About.php');
		$this->load->view('Home/Footer.php');
	}
}

?>