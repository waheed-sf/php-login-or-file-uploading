<nav class="navbar fixed-bottom navbar navbar-dark bg-primary">
  <a class="navbar-brand" href="#">Fixed bottom</a>
</nav>
</html>
</body>