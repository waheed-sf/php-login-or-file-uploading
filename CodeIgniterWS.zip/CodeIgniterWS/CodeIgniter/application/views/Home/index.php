
<marquee>
	<font size="20" color="Blue">
<h1>Welcome our web page</h1>
</font>
</marquee>
<center>
	
<font color="red"><h1>Muzammil ali khan</h1></font>
<font color="Green"><h2>Muzammil Abbas</h2></font>
<font color="Mehroon"><h3>Kamran</h3></font>
<font color="Purple"><h4>Wasiq</h4></font>
<font color="Blue"><h5>Khalid</h5></font>
<font color="Purple"><h6>Sumair</h6></font>

</center>